<?php $title='Track a report'; require 'header.php';
$code=strtoupper(trim($_GET['code'] ?? '')); $r=null;
if($code){ $s=$db->prepare("SELECT * FROM reports WHERE code=?"); $s->execute([$code]); $r=$s->fetch(); } ?>
<div class="panel mb-3"><form class="row g-2"><div class="col"><input name="code" class="form-control" placeholder="e.g. CP-1A2B3C" value="<?= e($code) ?>"></div>
<div class="col-auto"><button class="btn btn-brand">Track</button></div></form></div>
<?php if($code && !$r): ?><div class="alert alert-warning">No report found for that code. Check for typos.</div>
<?php elseif($r): ?><div class="panel"><div class="d-flex justify-content-between flex-wrap"><h2 class="h5"><?= e($r['title']) ?></h2><div><?= badge($r['severity']) ?> <?= badge($r['status']) ?></div></div>
<p class="text-muted mb-2"><?= e($r['kind']) ?> · <?= e($r['category']) ?> · <?= e($r['location']) ?> · filed <?= e($r['created_at']) ?></p>
<p><?= nl2br(e($r['description'])) ?></p>
<?php if($r['photo']): ?><img src="uploads/<?= e($r['photo']) ?>" class="img-fluid rounded mb-3" style="max-height:300px" alt="Report photo"><?php endif; ?>
<div class="border-start border-4 ps-3"><b>Response from the barangay</b><p class="mb-0"><?= $r['response'] ? nl2br(e($r['response'])) : 'No response yet.' ?></p></div></div><?php endif; ?>
<?php require 'footer.php'; ?>
