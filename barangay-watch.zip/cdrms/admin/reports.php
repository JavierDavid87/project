<?php $base='../'; $admin=true; $title='All reports'; require '../config.php'; require_admin(); require '../header.php';
$kind=$_GET['kind']??''; $st=$_GET['status']??''; $q=trim($_GET['q']??''); $w=[];$p=[];
if($kind){$w[]='kind=?';$p[]=$kind;} if($st){$w[]='status=?';$p[]=$st;}
if($q!==''){$w[]='(title LIKE ? OR code LIKE ? OR location LIKE ?)';array_push($p,"%$q%","%$q%","%$q%");}
$s=$db->prepare("SELECT * FROM reports ".($w?'WHERE '.implode(' AND ',$w):'')." ORDER BY id DESC"); $s->execute($p); $rows=$s->fetchAll(); ?>
<form class="row g-2 mb-3"><div class="col-md-4"><input name="q" class="form-control" placeholder="Search code, title, location" value="<?= e($q) ?>"></div>
<div class="col-md-3"><select name="kind" class="form-select"><option value="">All types</option><?php foreach(['Complaint','Disaster'] as $k): ?><option <?= $kind===$k?'selected':'' ?>><?= $k ?></option><?php endforeach; ?></select></div>
<div class="col-md-3"><select name="status" class="form-select"><option value="">All statuses</option><?php foreach(STATUSES as $k): ?><option <?= $st===$k?'selected':'' ?>><?= $k ?></option><?php endforeach; ?></select></div>
<div class="col-md-2"><button class="btn btn-brand w-100">Filter</button></div></form>
<div class="panel"><div class="table-responsive"><table class="table align-middle"><thead><tr><th>Code</th><th>Title</th><th>Type</th><th>Severity</th><th>Status</th><th>Filed</th><th></th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?= e($r['code']) ?></td><td><?= e($r['title']) ?></td><td><?= e($r['kind']) ?></td><td><?= badge($r['severity']) ?></td><td><?= badge($r['status']) ?></td><td><?= e(substr($r['created_at'],0,10)) ?></td>
<td><a class="btn btn-sm btn-brand" href="view.php?id=<?= $r['id'] ?>">Open</a></td></tr><?php endforeach; if(!$rows): ?><tr><td colspan="7" class="text-muted">No reports match these filters.</td></tr><?php endif; ?></tbody></table></div></div>
<?php require '../footer.php'; ?>
