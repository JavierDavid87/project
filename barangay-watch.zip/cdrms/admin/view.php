<?php $base='../'; $admin=true; $title='Report'; require '../config.php'; require_admin();
$id=(int)($_GET['id']??0); $s=$db->prepare("SELECT * FROM reports WHERE id=?"); $s->execute([$id]); $r=$s->fetch(); if(!$r) die('Report not found.');
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){ check_csrf();
  if(isset($_POST['delete'])){ if($r['photo']) @unlink(__DIR__.'/../uploads/'.$r['photo']); $db->prepare("DELETE FROM reports WHERE id=?")->execute([$id]); header('Location: reports.php'); exit; }
  $st=in_array($_POST['status']??'',STATUSES)?$_POST['status']:$r['status'];
  $db->prepare("UPDATE reports SET status=?,response=?,updated_at=CURRENT_TIMESTAMP WHERE id=?")->execute([$st,trim($_POST['response']??''),$id]);
  $s->execute([$id]); $r=$s->fetch(); $msg='Changes saved.'; }
require '../header.php'; ?>
<a href="reports.php" class="small">Back to all reports</a>
<div class="row g-3 mt-1"><div class="col-lg-7"><div class="panel"><div class="d-flex justify-content-between flex-wrap"><h1 class="h5"><?= e($r['title']) ?></h1><div><?= badge($r['severity']) ?> <?= badge($r['status']) ?></div></div>
<p class="text-muted"><?= e($r['code']) ?> · <?= e($r['kind']) ?>: <?= e($r['category']) ?> · <?= e($r['created_at']) ?></p>
<p><?= nl2br(e($r['description'])) ?></p><p><b>Location:</b> <?= e($r['location']) ?></p>
<p><b>Reporter:</b> <?= e($r['reporter']?:'Anonymous') ?> <?= $r['contact']?'('.e($r['contact']).')':'' ?></p>
<?php if($r['photo']): ?><img src="../uploads/<?= e($r['photo']) ?>" class="img-fluid rounded" style="max-height:320px" alt="Report photo"><?php endif; ?></div></div>
<div class="col-lg-5"><div class="panel"><h2 class="h6">Update this report</h2>
<?php if($msg): ?><div class="alert alert-success py-2"><?= e($msg) ?></div><?php endif; ?>
<form method="post"><input type="hidden" name="t" value="<?= csrf() ?>"><label class="form-label">Status</label>
<select name="status" class="form-select mb-3"><?php foreach(STATUSES as $x): ?><option <?= $r['status']===$x?'selected':'' ?>><?= $x ?></option><?php endforeach; ?></select>
<label class="form-label">Public response</label><textarea name="response" rows="4" class="form-control mb-3"><?= e($r['response']) ?></textarea>
<button class="btn btn-brand">Save changes</button>
<button name="delete" value="1" class="btn btn-outline-danger float-end" onclick="return confirm('Delete this report permanently?')">Delete report</button></form></div></div></div>
<?php require '../footer.php'; ?>
