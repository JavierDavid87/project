<?php $base='../'; $admin=true; $title='Dashboard'; require '../config.php'; require_admin(); require '../header.php';
$byStatus=$db->query("SELECT status,COUNT(*) c FROM reports GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
$urgent=$db->query("SELECT * FROM reports WHERE status NOT IN('Resolved','Rejected') ORDER BY kind='Disaster' DESC, CASE severity WHEN 'Critical' THEN 0 WHEN 'High' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END, id DESC LIMIT 8")->fetchAll(); ?>
<h1 class="h4 mb-3">Welcome, <?= e($_SESSION['name']) ?></h1>
<div class="row g-3 mb-4"><?php foreach(STATUSES as $s): ?><div class="col-6 col-md"><div class="stat <?= $s==='Pending'?'alert':'' ?>"><b><?= (int)($byStatus[$s]??0) ?></b><?= e($s) ?></div></div><?php endforeach; ?></div>
<div class="panel"><h2 class="h5">Needs attention first</h2>
<?php if(!$urgent): ?><p class="text-muted mb-0">Nothing open right now.</p><?php else: ?><div class="table-responsive"><table class="table align-middle">
<thead><tr><th>Code</th><th>Type</th><th>Location</th><th>Severity</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach($urgent as $r): ?><tr><td><?= e($r['code']) ?></td><td><?= e($r['kind']) ?>: <?= e($r['category']) ?></td><td><?= e($r['location']) ?></td><td><?= badge($r['severity']) ?></td><td><?= badge($r['status']) ?></td>
<td><a class="btn btn-sm btn-brand" href="view.php?id=<?= $r['id'] ?>">Open</a></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></div>
<?php require '../footer.php'; ?>
