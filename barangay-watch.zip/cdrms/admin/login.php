<?php $base='../'; $title='Staff login'; require '../header.php'; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){ check_csrf();
  $s=$db->prepare("SELECT * FROM users WHERE username=?"); $s->execute([trim($_POST['username']??'')]); $u=$s->fetch();
  if($u && password_verify($_POST['password']??'',$u['password'])){ session_regenerate_id(true); $_SESSION['uid']=$u['id']; $_SESSION['name']=$u['name']; header('Location: index.php'); exit; }
  $err='Wrong username or password.'; } ?>
<div class="panel mx-auto" style="max-width:400px"><h1 class="h4 mb-3">Staff login</h1>
<?php if($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>
<form method="post"><input type="hidden" name="t" value="<?= csrf() ?>">
<input name="username" class="form-control mb-2" placeholder="Username" required><input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
<button class="btn btn-brand w-100">Log in</button></form><p class="small text-muted mt-3 mb-0">Default: admin / admin123. Change it after first login.</p></div>
<?php require '../footer.php'; ?>
