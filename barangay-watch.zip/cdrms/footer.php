</main><footer class="text-center text-muted small py-4">Emergency? Call your local hotline first (911). Reports here are reviewed during office hours.</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script></body></html>
