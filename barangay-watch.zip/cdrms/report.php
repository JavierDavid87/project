<?php $title='File a report'; require 'header.php';
$kind = ($_REQUEST['kind'] ?? 'Complaint')==='Disaster' ? 'Disaster' : 'Complaint'; $err=[]; $done=null;
if ($_SERVER['REQUEST_METHOD']==='POST') { check_csrf();
  $f=fn($k)=>trim($_POST[$k] ?? '');
  $cats = $kind==='Disaster' ? DISASTER_CATS : COMPLAINT_CATS;
  if (!in_array($f('category'),$cats)) $err[]='Choose a category.';
  if (!in_array($f('severity'),['Low','Medium','High','Critical'])) $err[]='Choose a severity.';
  if (strlen($f('title'))<5) $err[]='Add a short title (at least 5 characters).';
  if (strlen($f('description'))<15) $err[]='Describe what happened in at least 15 characters.';
  if ($f('location')==='') $err[]='Enter the location.';
  $photo=null;
  if (!empty($_FILES['photo']['name'])) {
    $ok=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    $mime=@mime_content_type($_FILES['photo']['tmp_name']);
    if ($_FILES['photo']['error']!==0 || !isset($ok[$mime]) || $_FILES['photo']['size']>3*1024*1024) $err[]='Photo must be a JPG, PNG or WebP under 3 MB.';
    else { $photo=bin2hex(random_bytes(8)).'.'.$ok[$mime]; move_uploaded_file($_FILES['photo']['tmp_name'],__DIR__.'/uploads/'.$photo); } }
  if (!$err) { $code=($kind==='Disaster'?'DR':'CP').'-'.strtoupper(bin2hex(random_bytes(3)));
    $db->prepare("INSERT INTO reports(code,kind,category,severity,title,description,location,reporter,contact,photo) VALUES(?,?,?,?,?,?,?,?,?,?)")
       ->execute([$code,$kind,$f('category'),$f('severity'),$f('title'),$f('description'),$f('location'),$f('reporter'),$f('contact'),$photo]);
    $done=$code; } }
$cats = $kind==='Disaster' ? DISASTER_CATS : COMPLAINT_CATS; $v=fn($k)=>e($_POST[$k] ?? ''); ?>
<?php if($done): ?><div class="panel text-center"><h2 class="h4">Report received</h2><p>Keep this tracking code to check progress:</p>
<div class="code fw-bold mb-3"><?= e($done) ?></div><a class="btn btn-brand" href="track.php?code=<?= e($done) ?>">Track this report</a></div>
<?php else: ?><div class="panel"><ul class="nav nav-pills mb-3">
<li class="nav-item"><a class="nav-link <?= $kind==='Complaint'?'active':'' ?>" href="?kind=Complaint">Complaint</a></li>
<li class="nav-item"><a class="nav-link <?= $kind==='Disaster'?'active':'' ?>" href="?kind=Disaster">Disaster</a></li></ul>
<?php foreach($err as $m): ?><div class="alert alert-danger py-2"><?= e($m) ?></div><?php endforeach; ?>
<form method="post" enctype="multipart/form-data" class="row g-3"><input type="hidden" name="t" value="<?= csrf() ?>"><input type="hidden" name="kind" value="<?= $kind ?>">
<div class="col-md-6"><label class="form-label">Category</label><select name="category" class="form-select" required><option value="">Select…</option>
<?php foreach($cats as $c): ?><option <?= $v('category')===e($c)?'selected':'' ?>><?= e($c) ?></option><?php endforeach; ?></select></div>
<div class="col-md-6"><label class="form-label">Severity</label><select name="severity" class="form-select" required>
<?php foreach(['Low','Medium','High','Critical'] as $s): ?><option <?= $v('severity')===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select></div>
<div class="col-12"><label class="form-label">Title</label><input name="title" class="form-control" value="<?= $v('title') ?>" required></div>
<div class="col-12"><label class="form-label">What happened?</label><textarea name="description" rows="4" class="form-control" required><?= $v('description') ?></textarea></div>
<div class="col-12"><label class="form-label">Location</label><input name="location" class="form-control" placeholder="Street, purok or landmark" value="<?= $v('location') ?>" required></div>
<div class="col-md-6"><label class="form-label">Your name (optional)</label><input name="reporter" class="form-control" value="<?= $v('reporter') ?>"></div>
<div class="col-md-6"><label class="form-label">Phone or email (optional)</label><input name="contact" class="form-control" value="<?= $v('contact') ?>"></div>
<div class="col-12"><label class="form-label">Photo (optional)</label><input type="file" name="photo" accept="image/*" class="form-control"></div>
<div class="col-12"><button class="btn <?= $kind==='Disaster'?'btn-alert':'btn-brand' ?> btn-lg">Send report</button></div></form></div><?php endif; ?>
<?php require 'footer.php'; ?>
