<?php require_once __DIR__.'/config.php'; $base = $base ?? ''; ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title ?? 'Community Reports') ?> · Barangay Watch</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="<?= $base ?>style.css" rel="stylesheet"></head><body>
<nav class="navbar navbar-expand-md navbar-dark bg-brand"><div class="container">
<a class="navbar-brand fw-bold" href="<?= $base ?>index.php"><i class="bi bi-broadcast-pin"></i> Barangay Watch</a>
<button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nv"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="nv"><ul class="navbar-nav ms-auto">
<?php if (!empty($admin)): ?>
<li class="nav-item"><a class="nav-link" href="index.php">Dashboard</a></li>
<li class="nav-item"><a class="nav-link" href="reports.php">All reports</a></li>
<li class="nav-item"><a class="nav-link" href="../index.php">Public site</a></li>
<li class="nav-item"><a class="nav-link" href="logout.php">Log out</a></li>
<?php else: ?>
<li class="nav-item"><a class="nav-link" href="<?= $base ?>report.php">File a report</a></li>
<li class="nav-item"><a class="nav-link" href="<?= $base ?>track.php">Track a report</a></li>
<li class="nav-item"><a class="nav-link" href="<?= $base ?>admin/login.php">Staff login</a></li>
<?php endif; ?></ul></div></div></nav><main class="container py-4">
