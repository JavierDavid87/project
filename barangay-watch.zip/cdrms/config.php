<?php
session_start();
$db = new PDO('sqlite:' . __DIR__ . '/data/app.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, name TEXT);
CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY, code TEXT UNIQUE, kind TEXT, category TEXT, severity TEXT,
 title TEXT, description TEXT, location TEXT, reporter TEXT, contact TEXT, photo TEXT,
 status TEXT DEFAULT 'Pending', response TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT);");
if (!$db->query("SELECT COUNT(*) FROM users")->fetchColumn())
  $db->prepare("INSERT INTO users(username,password,name) VALUES('admin',?,'Administrator')")->execute([password_hash('admin123', PASSWORD_DEFAULT)]);
const STATUSES = ['Pending','Acknowledged','In Progress','Resolved','Rejected'];
const COMPLAINT_CATS = ['Noise','Garbage / Sanitation','Road / Infrastructure','Water / Electricity','Peace & Order','Other'];
const DISASTER_CATS = ['Flood','Fire','Earthquake','Typhoon / Storm','Landslide','Power Outage','Other'];
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function csrf(){ return $_SESSION['t'] ??= bin2hex(random_bytes(16)); }
function check_csrf(){ if (!hash_equals($_SESSION['t'] ?? '', $_POST['t'] ?? '')) die('Invalid session token.'); }
function require_admin(){ if (empty($_SESSION['uid'])) { header('Location: login.php'); exit; } }
function badge($s){ $m=['Pending'=>'secondary','Acknowledged'=>'info','In Progress'=>'warning','Resolved'=>'success','Rejected'=>'dark',
 'Critical'=>'danger','High'=>'warning','Medium'=>'info','Low'=>'secondary']; return '<span class="badge text-bg-'.($m[$s]??'secondary').'">'.e($s).'</span>'; }
