# Barangay Watch - Community Complaint & Disaster Reporting System
Requirements: PHP 8+ with pdo_sqlite and fileinfo (both on by default in XAMPP).
Run: copy this folder to htdocs, or run `php -S localhost:8000` inside it, then open http://localhost:8000
Admin: /admin/login.php - admin / admin123 (change it). The SQLite DB is created automatically in /data.
