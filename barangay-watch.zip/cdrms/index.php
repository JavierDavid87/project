<?php $title='Home'; require 'header.php';
$c=fn($w)=>(int)$db->query("SELECT COUNT(*) FROM reports $w")->fetchColumn();
$recent=$db->query("SELECT code,kind,category,severity,location,status,created_at FROM reports ORDER BY id DESC LIMIT 6")->fetchAll(); ?>
<div class="hero mb-4"><h1 class="display-6 fw-bold">See something wrong in the community? Tell us.</h1>
<p class="lead mb-4">Report a complaint or a disaster in your area and follow it until it is resolved.</p>
<a href="report.php?kind=Disaster" class="btn btn-alert btn-lg me-2"><i class="bi bi-exclamation-triangle"></i> Report a disaster</a>
<a href="report.php?kind=Complaint" class="btn btn-light btn-lg">File a complaint</a></div>
<div class="row g-3 mb-4">
<div class="col-6 col-md-3"><div class="stat"><b><?= $c('') ?></b>Total reports</div></div>
<div class="col-6 col-md-3"><div class="stat alert"><b><?= $c("WHERE kind='Disaster' AND status NOT IN('Resolved','Rejected')") ?></b>Open disasters</div></div>
<div class="col-6 col-md-3"><div class="stat"><b><?= $c("WHERE status IN('Pending','Acknowledged','In Progress')") ?></b>Being handled</div></div>
<div class="col-6 col-md-3"><div class="stat"><b><?= $c("WHERE status='Resolved'") ?></b>Resolved</div></div></div>
<div class="panel"><h2 class="h5">Recent reports</h2>
<?php if(!$recent): ?><p class="text-muted mb-0">No reports yet. File the first one.</p><?php else: ?>
<div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Code</th><th>Type</th><th>Location</th><th>Severity</th><th>Status</th></tr></thead><tbody>
<?php foreach($recent as $r): ?><tr><td><a href="track.php?code=<?= e($r['code']) ?>"><?= e($r['code']) ?></a></td>
<td><?= e($r['kind']) ?>: <?= e($r['category']) ?></td><td><?= e($r['location']) ?></td><td><?= badge($r['severity']) ?></td><td><?= badge($r['status']) ?></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?></div>
<?php require 'footer.php'; ?>
